#!/usr/bin/env python
from Arduino import Arduino
#import subprocess
import time
import smtplib

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login("email@gmail.com", "password")
print "Logged IN"
msg = "Switch On"
trigPin=12
echoPin=8
fg=1
board = Arduino(9600,port="COM3")
board.pinMode(10, "INPUT")
kl=0
while True:
    if (board.digitalRead(10)):
        print "Message Sent"
        server.sendmail("email@gmail.com", "sendto@gmail.com", msg)
        time.sleep(1);
server.quit()

